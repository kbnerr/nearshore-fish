library(vegan)
library(tidyverse)

########## Additional Data Prep ##########

# Let's make a data.matrix version of the spp19 CPUE data:
spp19.matrix = data.matrix(spp19[!colnames(spp19) %in% c("SiteID")])
is.matrix(spp19.matrix)

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
spp19.bc = vegdist(spp19.matrix, method = "bray")

# We need to make sure the species and env 2019 matrices match SiteID's...
env19 = arrange(env19, SiteID)

# Check:
spp19$SiteID == env19$SiteID # Good!

########## BIOENV ###########
(best19 = bioenv(comm = spp19.matrix, env = env19[!colnames(env19) %in% c("SiteID", "Date", "Day")], method = "spearman"))
summary(best19)
# Look like 'Veg' is not a good environmental fit...

########## Mantel test on Veg ###########
env19.dist = dist(env19.matrix[, "Veg"])
(env19.mantel = mantel(xdis = spp19.bc, ydis = env19.dist, 
                       method  = "spearman", permutations = 4999))
hist(env19.mantel$perm, xlim=c(-0.4, 1))
abline(v = env19.mantel$statistic, col=4, lwd=2)

########## PERMANOVA test on Veg ############
adonis(spp19.bc ~ Veg, data = env19, by = NULL, permutations = 999)

########## Species ~ Veg ############

spp19.species = colnames(spp19.matrix)

for (i in spp19.species) {
  tmp = filter(cpue.long, Common == i)
  tmp = left_join(tmp, site, by = "SiteID")
  p = ggplot(data = tmp, aes(x = Date, y = CPUE)) +
    geom_col() +
    labs(title = paste(i, " CPUE"))
  print(p)
}




tmp1 = select(env19, SiteID, Veg)
tmp2 = select(spp19, SiteID, `Armorhead Sculpin`)
tmp3 = full_join(tmp1, spp19, by = "SiteID")
tmp4 = lm(`Armorhead Sculpin` ~ Veg, data = tmp3)
summary(tmp4)
tmp4

for (i in spp19.species) {
  tmp1 = select(env19, SiteID, Veg)
  tmp2 = select(spp19, SiteID, i)
  tmp3 = full_join(tmp1, tmp2, by = "SiteID")
  p = plot(i ~ Veg, data = tmp3)
  print(p)
}

plot(`Armorhead Sculpin` ~ Veg, data = tmp3)

ggplot(data = tmp3, x = Veg, y = )
lm(env19$Veg ~ spp19[colnames(spp19) %in% c("SiteID", "Armorhead Sculpin"])

########## envfit() vector superimpose on NMDS ############
# We can superimpose our envfit() vector onto the fish community ordination:
ef1 = envfit(spp19.mds2, env19, choices = 1:2, permutations = 999)
summary(ef1)
ordisurf(cpue.mds2, env$Day)
plot(ef1, p.max=0.05)
ef1.gg = as.data.frame(scores(ef1, display = "vectors"))
ef1.gg = cbind(ef1.gg, Label = rownames(ef1.gg))