######## NMDS Ordination of Family CPUE using All 2018/2019 data ########

# Let's make a data.matrix version of the fam1918 CPUE data:
fam1918.matrix = data.matrix(fam1918[!colnames(fam1918) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
fam1918.bc = vegdist(fam1918.matrix, method = "bray")
round(fam1918.bc, 2)

# Let's check our dimensions:
dimcheckMDS(fam1918.matrix)
# looks like we're just below .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
fam1918.mds2 = metaMDS(fam1918.matrix, k = 2)
stressplot(fam1918.mds2)
plot(fam1918.mds2, type = "t")
scores(fam1918.mds2)
fam1918.mds2.scores = as.data.frame(scores(fam1918.mds2))

# Add grouping variables for plotting:
fam1918.mds2.scores$SiteID = site1918$SiteID
fam1918.mds2.scores$Site = site1918$Site
fam1918.mds2.scores$Date = site1918$Date
fam1918.mds2.scores$FC = site1918$FC
fam1918.mds2.spp = as.data.frame(scores(fam1918.mds2, "species"))
fam1918.mds2.spp$Species = rownames(fam1918.mds2.spp)
fam1918.mds2.scores = mutate(fam1918.mds2.scores, 'Site Location' = case_when(Site %in% c("Glacier Spit", "Halibut Cove", "China Poot") ~ "Inner Bay",
                                                                              Site %in% c("Barabara", "Seldovia Harbor", "Tutka Bay", "Anchor River") ~ "Outer Bay"))
fam1918.mds2.scores$`Site Location` = factor(fam1918.mds2.scores$`Site Location`, levels = c("Inner Bay", "Outer Bay"))

### fam1918
p = ggplot(fam1918.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_text(data = fam1918.mds2.spp,
            aes(x = NMDS1, y = NMDS2, label = Species),
            size = 3.5, alpha = .9, check_overlap = FALSE) +
  geom_point(aes(colour = month(Date), size = 5)) +
  geom_text(aes(label = NA), position = position_nudge(y = .05)) +
  theme_bw() +
  theme(axis.text.x = element_blank(),  # remove x-axis text
        axis.text.y = element_blank(), # remove y-axis text
        axis.ticks = element_blank(),  # remove axis ticks
        axis.title.x = element_text(size = 15),
        axis.title.y = element_text(size = 15),
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  #remove major-grid labels
        panel.grid.minor = element_blank(),  #remove minor-grid labels
        plot.background = element_blank(),
        legend.position = c(.2, .05),
        legend.direction = "horizontal",
        legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
        text = element_text(family = "Times", size = 12)) +
  coord_cartesian()

annotate_figure(p, top =  text_grob(paste("Stress =", round(fam1918.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

### fam18