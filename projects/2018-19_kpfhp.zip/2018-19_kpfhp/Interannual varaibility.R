# Interannual variability
library(tidyverse)
library(vegan)
library(goeveg)
library(ggpubr)
library(lubridate)

#source("/Users/chrisguo/Desktop/Directory/Nearshore-year2/R scripts/data prep KPFHP report.R")

######## Additional data prep ########
Reach18 = dat18 %>% select(SeineID, Reach)
Reach19 = dat19 %>% select(SeineID, Reach)
Reach = bind_rows(Reach18, Reach19)
reach = left_join(fish1918, Reach, by = "SeineID") %>%
  select(SeineID, SiteID, Reach) %>%
  distinct()
rm(Reach18, Reach19) # we don't need these anymore

spp.shared.full = fish1918 %>% 
  filter(Site %in% c("Anchor River", "China Poot", "Tutka Bay", "Halibut Cove")) %>%
  select(SeineID, Common, Count) %>%
  group_by(SeineID, Common) %>%
  mutate(Seine.Count = sum(Count, na.rm = T)) %>%
  select(-Count) %>%
  distinct() %>% 
  left_join(., reach, by = "SeineID") %>%
  mutate(CPUE = (Seine.Count/Reach)^0.25) %>%
  select(SiteID, SeineID, Common, CPUE)

# Here is our spp CPUE data in long format:
spp.shared.long = spp.shared.full %>%
  group_by(SiteID, Common) %>%
  mutate(avg.CPUE = mean(CPUE, na.rm = T),
         sd.CPUE = sd(CPUE, na.rm = T),
         sum.CPUE = sum(CPUE, na.rm = T)) %>%
  select(SiteID, Common, avg.CPUE, sd.CPUE, sum.CPUE) %>%
  distinct()

# Let's take a look at the raw species CPUE:
spp.shared.long %>%
  ungroup() %>%
  select(Common, avg.CPUE) %>%
  group_by(Common) %>%
  summarise(sum.avg.CPUE = sum(avg.CPUE, na.rm = T)) %>%
  ggplot(data = ., aes(x = Common, y = sum.avg.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Species", y = "4th-Root CPUE")

# Seems okay, except that we may want to drop the unidentified species of which we could not define lifestage...
spp.shared.long = spp.shared.long %>%
  filter(!Common %in% c("Unidentified Sculpin", "Unidentified Gadid", "Unidentified Greenling", "Unidentified Flatfish"))
# One final check:
spp.shared.long %>%
  ungroup() %>%
  select(Common, avg.CPUE) %>%
  group_by(Common) %>%
  summarise(sum.avg.CPUE = sum(avg.CPUE)) %>%
  ggplot(data = ., aes(x = Common, y = sum.avg.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Species", y = "Summed Average 4th-Root CPUE")

spp.shared.long %>%
  ungroup() %>%
  select(Common, sum.CPUE) %>%
  group_by(Common) %>%
  summarise(sum.sum.CPUE = sum(sum.CPUE)) %>%
  ggplot(data = ., aes(x = Common, y = sum.sum.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Species", y = "Total 4th-Root CPUE")

# Great, now let's create our site x species data frame. We'll use the site average CPUE:
spp.shared = spp.shared.long %>%
  select(SiteID, Common, avg.CPUE) %>%
  spread(., Common, avg.CPUE)
spp.shared[is.na(spp.shared)] = 0

# Let's also take a look ahead at a site x family df using the site average CPUE
spp.shared.long %>%
  left_join(SpeciesList, by = "Common") %>%
  ungroup() %>%
  group_by(SiteID, Family) %>%
  transmute(sum.avg.CPUE = sum(avg.CPUE)) %>%
  distinct()

# view the data
spp.shared # Woo! lots of zero's

# We should check to see if any of these species do not occur at any sites now that two are removed...
colSums(spp.shared[-1])
# Let's view instances of single catch species...
colSums(spp.shared[-1] > 0)
# great!



# This is the full transformed family CPUE data
fam.shared.full = fish1918 %>% 
  filter(Site %in% c("Anchor River", "China Poot", "Tutka Bay", "Halibut Cove")) %>%
  select(SeineID, Family2, Count) %>%
  group_by(SeineID, Family2) %>%
  mutate(Seine.Count = sum(Count, na.rm = T)) %>%
  select(-Count) %>%
  distinct() %>%
  left_join(., reach, by = "SeineID") %>%
  mutate(CPUE = (Seine.Count/Reach)^0.25) %>%
  select(SiteID, SeineID, Family2, CPUE)

# Here is our family 2018 and 2019 CPUE data in long format:
fam.shared.long = fam.shared.full %>%
  group_by(SiteID, Family2) %>%
  mutate(avg.CPUE = mean(CPUE, na.rm = T),
         sd.CPUE = sd(CPUE, na.rm = T),
         sum.CPUE = sum(CPUE, na.rm = T)) %>%
  select(SiteID, Family2, avg.CPUE, sd.CPUE, sum.CPUE) %>%
  distinct()

rm(reach, Reach) # Don't need these anymore

# Let's take a look at the raw family CPUE:
fam.shared.long %>%
  ungroup() %>%
  select(Family2, avg.CPUE) %>%
  group_by(Family2) %>%
  summarise(sum.avg.CPUE = sum(avg.CPUE, na.rm = T)) %>%
  ggplot(data = ., aes(x = Family2, y = sum.avg.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Family", y = "Summed Average 4th-Root CPUE")

fam.shared.long %>%
  ungroup() %>%
  select(Family2, sum.CPUE) %>%
  group_by(Family2) %>%
  summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = T)) %>%
  ggplot(data = ., aes(x = Family2, y = sum.sum.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Family", y = "Total 4th-Root CPUE")

# Great, now let's create our site x family data frame. We'll use the site average CPUE:
fam.shared = fam.shared.long %>%
  select(SiteID, Family2, avg.CPUE) %>%
  spread(., Family2, avg.CPUE)
fam.shared[is.na(fam.shared)] = 0

# view the data
fam.shared # Woo! lots of zero's

# We should check to see if any of these families do not occur at any sites now that two are removed...
colSums(fam.shared[-1])
# Let's view instances of single catch families
colSums(fam.shared[-1] > 0)

# Let's double check that our long and spread data have the same species:
colnames(fam.shared[,-1])
sort(unique(fam.shared.long$Family2))
colnames(fam.shared[,-1]) == sort(unique(fam.shared.long$Family2))
# Looks good

# We need to create a site.shared df
site.shared = select(spp.shared, SiteID)
site.shared = site.shared %>%
  left_join(site1918, by = "SiteID") %>%
  select(-FC)

site.shared$SiteID == fam.shared$SiteID # just checking this

######## NMDS Ordination of Family CPUE ########

# Let's make a data.matrix version of the fam.shared CPUE data:
fam.shared.matrix = data.matrix(fam.shared[!colnames(fam.shared) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
fam.shared.bc = vegdist(fam.shared.matrix, method = "bray")
round(fam.shared.bc, 2)

# Let's check our dimensions:
dimcheckMDS(fam.shared.matrix)
# looks like we're just above .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
fam.shared.mds2 = metaMDS(fam.shared.matrix, k = 2)
stressplot(fam.shared.mds2)
plot(fam.shared.mds2, type = "t")
scores(fam.shared.mds2)
fam.shared.mds2.scores = as.data.frame(scores(fam.shared.mds2))

# Add grouping variables for plotting:
fam.shared.mds2.scores$SiteID = site.shared$SiteID
fam.shared.mds2.scores$Site = site.shared$Site
fam.shared.mds2.scores$Date = site.shared$Date
fam.shared.mds2.scores$Year = as.character(site.shared$Year)
fam.shared.mds2.spp = as.data.frame(scores(fam.shared.mds2, "species"))
fam.shared.mds2.spp$Species = rownames(fam.shared.mds2.spp)

fam.shared.mds2.scores = mutate(fam.shared.mds2.scores, Season = case_when(Date < "2018-09-01" ~ "Summer",
                                                                           Date > "2018-09-01" ~ "Fall"))
fam.shared.mds2.scores$Season = factor(fam.shared.mds2.scores$Season, levels = c("Summer", "Fall"))

# NMDS colored by Year
p = ggplot(fam.shared.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_text(data = fam.shared.mds2.spp,
              aes(x = NMDS1, y = NMDS2, label = Species),
              size = 3.5, alpha = .9, check_overlap = FALSE) +
    geom_point(aes(shape = Site, colour = Year),
               size = 5) +
    geom_text(aes(label = NA),
              position = position_nudge(y = .05)) +
    theme_bw() + 
    theme(axis.text.x = element_blank(),  # remove x-axis text
          axis.text.y = element_blank(), # remove y-axis text
          axis.ticks = element_blank(),  # remove axis ticks
          axis.title.x = element_text(size = 15),
          axis.title.y = element_text(size = 15),
          panel.background = element_blank(), 
          panel.grid.major = element_blank(),  #remove major-grid labels
          panel.grid.minor = element_blank(),  #remove minor-grid labels
          plot.background = element_blank(),
          legend.position = c(.2, .05),
          legend.direction = "horizontal",
          legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
          text = element_text(family = "Times", size = 12)) +
    coord_cartesian()

annotate_figure(p, top =  text_grob(paste("Stress =", round(fam.shared.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", fam.mds2$ndim, ", stress = ", round(fam.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(fam.mds2$stress, 3)),
# x = .9, family = "Times", size = 10))

######## NMDS Ordination of Species CPUE ########

# Let's make a data.matrix version of the spp.shared CPUE data:
spp.shared.matrix = data.matrix(spp.shared[!colnames(spp.shared) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
spp.shared.bc = vegdist(spp.shared.matrix, method = "bray")
round(spp.shared.bc, 2)

# Let's check our dimensions:
dimcheckMDS(spp.shared.matrix)
# looks like we're just above .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
spp.shared.mds2 = metaMDS(spp.shared.matrix, k = 2)
stressplot(spp.shared.mds2)
plot(spp.shared.mds2, type = "t")
scores(spp.shared.mds2)
spp.shared.mds2.scores = as.data.frame(scores(spp.shared.mds2))

# Add grouping variables for plotting:
spp.shared.mds2.scores$SiteID = site.shared$SiteID
spp.shared.mds2.scores$Site = site.shared$Site
spp.shared.mds2.scores$Date = site.shared$Date
spp.shared.mds2.scores$Year = as.character(site.shared$Year)
spp.shared.mds2.spp = as.data.frame(scores(spp.shared.mds2, "species"))
spp.shared.mds2.spp$Species = rownames(spp.shared.mds2.spp)

spp.shared.mds2.scores = mutate(spp.shared.mds2.scores, Season = case_when(Date < "2018-09-01" ~ "Summer",
                                                                           Date > "2018-09-01" ~ "Fall"))
spp.shared.mds2.scores$Season = factor(spp.shared.mds2.scores$Season, levels = c("Summer", "Fall"))

# NMDS colored by Year
(p = ggplot(spp.shared.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_text(data = spp.shared.mds2.spp,
            aes(x = NMDS1, y = NMDS2, label = Species),
            size = 3.5, alpha = .9, check_overlap = FALSE) +
  geom_point(aes(colour = Year),
             size = 5) +
  geom_text(aes(label = NA),
            position = position_nudge(y = .05)) +
  theme_bw() + 
  theme(axis.text.x = element_blank(),  # remove x-axis text
        axis.text.y = element_blank(), # remove y-axis text
        axis.ticks = element_blank(),  # remove axis ticks
        axis.title.x = element_text(size = 15),
        axis.title.y = element_text(size = 15),
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  #remove major-grid labels
        panel.grid.minor = element_blank(),  #remove minor-grid labels
        plot.background = element_blank(),
        legend.position = c(.90, .05),
        legend.direction = "horizontal",
        legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
        text = element_text(family = "Times", size = 12)) +
  coord_cartesian())

annotate_figure(p, top =  text_grob(paste("Stress =", round(spp.shared.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", spp.mds2$ndim, ", stress = ", round(spp.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(spp.mds2$stress, 3)),

######## BETADISPER & ANOSIM ########
spp.shared.beta = betadisper(spp.shared.bc, site.shared$Year)
anova(spp.shared.beta)
permutest(spp.shared.beta, permutations = 4999)
TukeyHSD(spp.shared.beta)
plot(spp.shared.beta)

(spp.shared.ano = anosim(spp.shared.matrix, site.shared$Year, permutations = 4999))
summary(spp.shared.ano)
plot(spp.shared.ano)

######## IndicSpecies #########
library(indicspecies)

# multipatt by flow class
spp.shared.indval = multipatt(x = spp.shared.matrix, cluster = site.shared$Year,
                      func = "IndVal.g",
                      control = how(nperm = 4999))
summary(spp.shared.indval, indvalcomp = TRUE, alpha = 1)
spp.shared.indval$sign

summary(simper(spp.shared.matrix, site.shared$Year, permutations = 999))
 


######## Species CPUE x year #########
spp.shared.long %>%
  left_join(site.shared) %>%
  ggplot(data = ., aes(x = Common, y = avg.CPUE, fill = as.character(Year))) +
  geom_errorbar(aes(ymin = avg.CPUE - sd.CPUE, ymax = avg.CPUE + sd.CPUE),
                position = "dodge") +
  geom_bar(stat = "identity", position = "dodge", width = 1)

  

spp.shared.long %>%
  filter(Common == "Lingcod")
