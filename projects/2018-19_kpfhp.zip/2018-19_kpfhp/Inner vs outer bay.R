# Inner bay vs outer bay
library(tidyverse)
library(vegan)
library(goeveg)
library(ggpubr)
library(lubridate)

# =source("/Users/chrisguo/Desktop/Directory/Nearshore-year2/R scripts/data prep KPFHP report.R")

######## Additional data prep ########

# Not needed
# We'll be using the 1918 df's which were already prepped.

######## NMDS Ordination of Family CPUE using only 2018 data ########

# Let's make a data.matrix version of the fam18 CPUE data:
fam18.matrix = data.matrix(fam18[!colnames(fam18) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
fam18.bc = vegdist(fam18.matrix, method = "bray")
round(fam18.bc, 2)

# Let's check our dimensions:
dimcheckMDS(fam18.matrix)
# looks like we're just below .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
fam18.mds2 = metaMDS(fam18.matrix, k = 2)
stressplot(fam18.mds2)
plot(fam18.mds2, type = "t")
scores(fam18.mds2)
fam18.mds2.scores = as.data.frame(scores(fam18.mds2))

# Add grouping variables for plotting:
fam18.mds2.scores$SiteID = site18$SiteID
fam18.mds2.scores$Site = site18$Site
fam18.mds2.scores$Date = site18$Date
fam18.mds2.scores$FC = site18$FC
fam18.mds2.spp = as.data.frame(scores(fam18.mds2, "species"))
fam18.mds2.spp$Species = rownames(fam18.mds2.spp)
fam18.mds2.scores = mutate(fam18.mds2.scores, 'Site Location' = case_when(Site %in% c("Glacier Spit", "Halibut Cove", "China Poot") ~ "Inner Bay",
                                                                              Site %in% c("Barabara", "Seldovia Harbor", "Tutka Bay", "Anchor River") ~ "Outer Bay"))
fam18.mds2.scores$`Site Location` = factor(fam18.mds2.scores$`Site Location`, levels = c("Inner Bay", "Outer Bay"))

### NMDS ordintation
(p1 = ggplot(data = fam18.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_text(data = fam18.mds2.spp,
            aes(x = NMDS1, y = NMDS2, label = Species,),
            size = 3.5, alpha = .9, check_overlap = FALSE) +
  geom_point(aes(color = `Site Location`, shape = Site), size = 5) +
  scale_shape_manual(values = c(16, 17, 15, 3, 16, 17, 15),
                     breaks = c("Anchor River", "Tutka Bay", "Barabara", "Seldovia Harbor", "China Poot", "Halibut Cove", "Glacier Spit")) +
  guides(color = FALSE,
          shape = guide_legend(override.aes = list(color = c(rep('#00bfc4', 4), rep('#f8766d', 3))))) + 
  geom_text(aes(label = NA), position = position_nudge(y = .05)) +
  theme_bw() +
  theme(axis.text.x = element_blank(),  # remove x-axis text
        axis.text.y = element_blank(), # remove y-axis text
        axis.ticks = element_blank(),  # remove axis ticks
        axis.title.x = element_text(size = 15),
        axis.title.y = element_text(size = 15),
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  #remove major-grid labels
        panel.grid.minor = element_blank(),  #remove minor-grid labels
        plot.background = element_blank(),
        legend.position = c(.75, .95),
        legend.direction = "horizontal",
        legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
        text = element_text(family = "Times", size = 12)) +
  coord_cartesian())

annotate_figure(p1, top =  text_grob(paste("Stress =", round(fam18.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", fam.mds2$ndim, ", stress = ", round(fam.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(fam.mds2$stress, 3)),
# x = .9, family = "Times", size = 10))

######## NMDS ordination of Family CPUE using shared 2018/2019 data ##########

# Let's make a data.matrix version of the fam.shared CPUE data:
fam.shared.matrix = data.matrix(fam.shared[!colnames(fam.shared) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
fam.shared.bc = vegdist(fam.shared.matrix, method = "bray")
round(fam.shared.bc, 2)

# Let's check our dimensions:
dimcheckMDS(fam.shared.matrix)
# looks like we're just above .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
fam.shared.mds2 = metaMDS(fam.shared.matrix, k = 2)
stressplot(fam.shared.mds2)
plot(fam.shared.mds2, type = "t")
scores(fam.shared.mds2)
fam.shared.mds2.scores = as.data.frame(scores(fam.shared.mds2))

# Add grouping variables for plotting:
fam.shared.mds2.scores$SiteID = site.shared$SiteID
fam.shared.mds2.scores$Site = site.shared$Site
fam.shared.mds2.scores$Date = site.shared$Date
fam.shared.mds2.scores$Year = as.character(site.shared$Year)
fam.shared.mds2.spp = as.data.frame(scores(fam.shared.mds2, "species"))
fam.shared.mds2.spp$Species = rownames(fam.shared.mds2.spp)

fam.shared.mds2.scores = mutate(fam.shared.mds2.scores, 'Site Location' = case_when(Site %in% c("Glacier Spit", "Halibut Cove", "China Poot") ~ "Inner Bay",
                                                                                    Site %in% c("Barabara", "Seldovia Harbor", "Tutka Bay", "Anchor River") ~ "Outer Bay"))
fam.shared.mds2.scores$`Site Location` = factor(fam.shared.mds2.scores$`Site Location`, levels = c("Inner Bay", "Outer Bay"))

# NMDS for shared 2018/2019 data colored by inner/outer bay

(p2 = ggplot(fam.shared.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
  geom_text(data = fam.shared.mds2.spp,
            aes(x = NMDS1, y = NMDS2, label = Species),
            size = 3.5, alpha = .9, check_overlap = FALSE) +
  geom_point(aes(shape = Site, colour = `Site Location`),
             size = 5) +
  scale_shape_manual(values = c(16,17,16,17),
                     breaks = c("Anchor River", "Tutka Bay", "China Poot", "Halibut Cove")) +
  guides(color = FALSE,
         shape = guide_legend(override.aes = list(color = c(rep('#00bfc4', 2), rep('#f8766d', 2))))) +
  geom_text(aes(label = NA),
            position = position_nudge(y = .05)) +
  theme_bw() + 
  theme(axis.text.x = element_blank(),  # remove x-axis text
        axis.text.y = element_blank(), # remove y-axis text
        axis.ticks = element_blank(),  # remove axis ticks
        axis.title.x = element_text(size = 15),
        axis.title.y = element_text(size = 15),
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  #remove major-grid labels
        panel.grid.minor = element_blank(),  #remove minor-grid labels
        plot.background = element_blank(),
        legend.position = "none",
        legend.direction = "horizontal",
        legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
        text = element_text(family = "Times", size = 12)) +
  coord_cartesian())

annotate_figure(p2, top =  text_grob(paste("Stress =", round(fam.shared.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", fam.mds2$ndim, ", stress = ", round(fam.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(fam.mds2$stress, 3)),
# x = .9, family = "Times", size = 10))

######## NMDS Ordination of Species CPUE using only 2018 data ########

# Let's make a data.matrix version of the spp18 CPUE data:
spp18.matrix = data.matrix(spp18[!colnames(spp18) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
spp18.bc = vegdist(spp18.matrix, method = "bray")
round(spp18.bc, 2)

# Let's check our dimensions:
dimcheckMDS(spp18.matrix)
# looks like we're just below .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
spp18.mds2 = metaMDS(spp18.matrix, k = 2)
stressplot(spp18.mds2)
plot(spp18.mds2, type = "t")
scores(spp18.mds2)
spp18.mds2.scores = as.data.frame(scores(spp18.mds2))

# Add grouping variables for plotting:
spp18.mds2.scores$SiteID = site18$SiteID
spp18.mds2.scores$Site = site18$Site
spp18.mds2.scores$Date = site18$Date
spp18.mds2.scores$FC = site18$FC
spp18.mds2.spp = as.data.frame(scores(spp18.mds2, "species"))
spp18.mds2.spp$Species = rownames(spp18.mds2.spp)
spp18.mds2.scores = mutate(spp18.mds2.scores, 'Site Location' = case_when(Site %in% c("Glacier Spit", "Halibut Cove", "China Poot") ~ "Inner Bay",
                                                                          Site %in% c("Barabara", "Seldovia Harbor", "Tutka Bay", "Anchor River") ~ "Outer Bay"))
spp18.mds2.scores$`Site Location` = factor(spp18.mds2.scores$`Site Location`, levels = c("Inner Bay", "Outer Bay"))

### NMDS ordintation
(p4 = ggplot(data = spp18.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_text(data = spp18.mds2.spp,
              aes(x = NMDS1, y = NMDS2, label = Species,),
              size = 3.5, alpha = .9, check_overlap = FALSE) +
    geom_point(aes(color = `Site Location`, shape = Site), size = 5) +
    scale_shape_manual(values = c(16, 17, 15, 3, 16, 17, 15),
                       breaks = c("Anchor River", "Tutka Bay", "Barabara", "Seldovia Harbor", "China Poot", "Halibut Cove", "Glacier Spit")) +
    guides(color = FALSE,
           shape = guide_legend(override.aes = list(color = c(rep('#00bfc4', 4), rep('#f8766d', 3))))) + 
    geom_text(aes(label = NA), position = position_nudge(y = .05)) +
    theme_bw() +
    theme(axis.text.x = element_blank(),  # remove x-axis text
          axis.text.y = element_blank(), # remove y-axis text
          axis.ticks = element_blank(),  # remove axis ticks
          axis.title.x = element_text(size = 15),
          axis.title.y = element_text(size = 15),
          panel.background = element_blank(), 
          panel.grid.major = element_blank(),  #remove major-grid labels
          panel.grid.minor = element_blank(),  #remove minor-grid labels
          plot.background = element_blank(),
          legend.position = c(.75, .95),
          legend.direction = "horizontal",
          legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
          text = element_text(family = "Times", size = 12)) +
    coord_cartesian())

annotate_figure(p4, top =  text_grob(paste("Stress =", round(spp18.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", spp.mds2$ndim, ", stress = ", round(spp.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(spp.mds2$stress, 3)),

######## NMDS ordination of Species CPUE using shared 2018/2019 data #########

# Let's make a data.matrix version of the spp.shared CPUE data:
spp.shared.matrix = data.matrix(spp.shared[!colnames(spp.shared) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
spp.shared.bc = vegdist(spp.shared.matrix, method = "bray")
round(spp.shared.bc, 2)

# Let's check our dimensions:
dimcheckMDS(spp.shared.matrix)
# looks like we're just above .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
spp.shared.mds2 = metaMDS(spp.shared.matrix, k = 2)
stressplot(spp.shared.mds2)
plot(spp.shared.mds2, type = "t")
scores(spp.shared.mds2)
spp.shared.mds2.scores = as.data.frame(scores(spp.shared.mds2))

# Add grouping variables for plotting:
spp.shared.mds2.scores$SiteID = site.shared$SiteID
spp.shared.mds2.scores$Site = site.shared$Site
spp.shared.mds2.scores$Date = site.shared$Date
spp.shared.mds2.scores$Year = as.character(site.shared$Year)
spp.shared.mds2.spp = as.data.frame(scores(spp.shared.mds2, "species"))
spp.shared.mds2.spp$Species = rownames(spp.shared.mds2.spp)

spp.shared.mds2.scores = mutate(spp.shared.mds2.scores, 'Site Location' = case_when(Site %in% c("Glacier Spit", "Halibut Cove", "China Poot") ~ "Inner Bay",
                                                                                    Site %in% c("Barabara", "Seldovia Harbor", "Tutka Bay", "Anchor River") ~ "Outer Bay"))
spp.shared.mds2.scores$`Site Location` = factor(spp.shared.mds2.scores$`Site Location`, levels = c("Inner Bay", "Outer Bay"))

# NMDS for shared 2018/2019 data colored by inner/outer bay

(p5 = ggplot(spp.shared.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_text(data = spp.shared.mds2.spp,
              aes(x = NMDS1, y = NMDS2, label = Species),
              size = 3.5, alpha = .9, check_overlap = FALSE) +
    geom_point(aes(shape = Site, colour = `Site Location`),
               size = 5) +
    scale_shape_manual(values = c(16,17,16,17),
                       breaks = c("Anchor River", "Tutka Bay", "China Poot", "Halibut Cove")) +
    guides(color = FALSE,
           shape = guide_legend(override.aes = list(color = c(rep('#00bfc4', 2), rep('#f8766d', 2))))) +
    geom_text(aes(label = NA),
              position = position_nudge(y = .05)) +
    theme_bw() + 
    theme(axis.text.x = element_blank(),  # remove x-axis text
          axis.text.y = element_blank(), # remove y-axis text
          axis.ticks = element_blank(),  # remove axis ticks
          axis.title.x = element_text(size = 15),
          axis.title.y = element_text(size = 15),
          panel.background = element_blank(), 
          panel.grid.major = element_blank(),  #remove major-grid labels
          panel.grid.minor = element_blank(),  #remove minor-grid labels
          plot.background = element_blank(),
          legend.position = c(.2, .9),
          legend.direction = "horizontal",
          legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
          text = element_text(family = "Times", size = 12)) +
    coord_cartesian())

annotate_figure(p5, top =  text_grob(paste("Stress =", round(spp.shared.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

######## Combine NMDS's from fam18 and fam.shared ##########

# time eslapse error for this... couldn't figure out how to solve...
(p6 = ggarrange(p4, p5,
               ncol = 2,
               common.legend = TRUE, legend = "bottom",
               labels = "AUTO", align = "hv"))
(p6.a = annotate_figure(p6, top = text_grob(paste("Stress =", round(spp18.mds2$stress, 3)), x = 0.05, vjust = 4, family = "Times", size = 10)))
(p6.b = annotate_figure(p6.a, top = text_grob(paste("Stress =", round(spp.shared.mds2$stress, 3)), x = 0.55, vjust = 6, family = "Times", size = 10)))

######## BETADISPER & ANOSIM ########

### for 2018 ony data
spp18.beta = betadisper(spp18.bc, spp18.mds2.scores$`Site Location`)
anova(spp18.beta)
permutest(spp18.beta, permutations = 4999)
TukeyHSD(spp18.beta)
plot(spp18.beta)

(spp18.ano = anosim(spp18.matrix, spp18.mds2.scores$`Site Location`, permutations = 4999))
summary(spp18.ano)
plot(spp18.ano)

### for 2018/2019 shared data

spp.shared.beta = betadisper(spp.shared.bc, spp.shared.mds2.scores$`Site Location`)
anova(spp.shared.beta)
permutest(spp.shared.beta, permutations = 4999)
TukeyHSD(spp.shared.beta)
plot(spp.shared.beta)

(spp.shared.ano = anosim(spp.shared.matrix, spp.shared.mds2.scores$`Site Location`, permutations = 4999))
summary(spp.shared.ano)
plot(spp.shared.ano)

######## IndicSpecies #########
library(indicspecies)

### For 2018 only data

site18 = mutate(site18, Location = case_when(Site %in% c("Anchor River", "Tutka Bay", "Barabara", "Seldovia Harbor") ~ "Outer Bay",
                                             Site %in% c("China Poot", "Halibut Cove", "Glacier Spit") ~ "Inner Bay"))
spp18.indval = multipatt(x = spp18.matrix, cluster = site18$Location,
                            func = "IndVal.g",
                            control = how(nperm = 4999))
summary(spp18.indval, indvalcomp = TRUE, alpha = 1)
spp18.indval$sign

summary(simper(spp18.matrix, site18$Location, permutations = 999))

### For 2018/2019 shared data

site.shared = mutate(site.shared, Location = case_when(Site %in% c("Anchor River", "Tutka Bay", "Barabara", "Seldovia Harbor") ~ "Outer Bay",
                                             Site %in% c("China Poot", "Halibut Cove", "Glacier Spit") ~ "Inner Bay"))
spp.shared.indval = multipatt(x = spp.shared.matrix, cluster = site.shared$Location,
                         func = "IndVal.g",
                         control = how(nperm = 4999))
summary(spp.shared.indval, indvalcomp = TRUE, alpha = 1)
spp.shared.indval$sign

summary(simper(spp.shared.matrix, site.shared$Location, permutations = 999))

######## Species CPUE x FC #########
spp.flow.long %>%
  left_join(site.flow) %>%
  ggplot(data = ., aes(x = Common, y = avg.CPUE, fill = as.character(FC))) +
  geom_errorbar(aes(ymin = avg.CPUE - sd.CPUE, ymax = avg.CPUE + sd.CPUE),
                position = "dodge") +
  geom_bar(stat = "identity", position = "dodge", width = 1)


spp.flow.long %>%
  filter(Common == "Lingcod")
