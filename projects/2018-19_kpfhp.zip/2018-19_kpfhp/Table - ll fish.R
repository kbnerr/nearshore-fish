library(tidyverse)

########## All fish size table ############
(size.table = fish1918 %>%
  left_join(SpeciesList, by = "Common") %>%
  select(Family = Family.y, Scientific, Common, Length, Count, LengthType) %>%
  filter(!is.na(Length) & Count == 1) %>%
  group_by(Common) %>%
  mutate(avg.Length = round(mean(Length, na.rm = T), 0),
         sd.Length = round(sd(Length, na.rm = T), 0),
         min = min(Length, na.rm = T),
         max = max(Length, na.rm = T),
         n = sum(Count, na.rm = T)) %>%
  select(-Length, -Count) %>%
  unite(col = "Range", c("min", "max"), sep = " - ", remove = TRUE) %>%
  unite(col = "tmp1", c("avg.Length", "sd.Length"), sep = " (", remove = TRUE) %>%
  mutate(tmp2 = ")") %>%
  unite(col = "avg.sd", c("tmp1", "tmp2"), sep = "", remove = TRUE) %>%
  distinct() %>%
  arrange(Family, Scientific))
write.csv(size.table, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/Size summary.csv", row.names = FALSE)

########## All fish caught combined ###########
tmp = spp1918.long %>%
  group_by(Common) %>%
  summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
  left_join(SpeciesList, by = "Common") %>%
  select(Family,
         Common,
         Scientific,
         Total.CPUE = sum.sum.CPUE) %>%
  ungroup() %>%
  group_by(Family) %>%
  mutate(fam.CPUE = sum(Total.CPUE)) %>%
  ungroup() %>%
  mutate(perc.fam.CPUE = 100*fam.CPUE/sum(Total.CPUE)) %>%
  select(Family,
         fam.CPUE,
         perc.fam.CPUE,
         Common,
         Scientific,
         Total.CPUE) %>%
  arrange(desc(perc.fam.CPUE),
          desc(Total.CPUE))
write.csv(tmp, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/All-fish-caught.csv", row.names = FALSE)

########## CPUE by site ##########
(anchor.cpue = spp1918.long %>%
  left_join(site1918, by = "SiteID") %>%
  filter(Site == "Anchor River") %>%
  group_by(Common) %>%
  summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
  select(Common,
         Total.CPUE = sum.sum.CPUE) %>%
  ungroup() %>%
  select(Common,
         Anchor = Total.CPUE))
write.csv(anchor.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-anchor.csv", row.names = FALSE)

(barabara.cpue = spp1918.long %>%
    left_join(site1918, by = "SiteID") %>%
    filter(Site == "Barabara") %>%
    group_by(Common) %>%
    summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
    select(Common,
           Total.CPUE = sum.sum.CPUE) %>%
    ungroup() %>%
    select(Common,
           Barabara = Total.CPUE))
write.csv(barabara.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-barabara.csv", row.names = FALSE)

(chinapoot.cpue = spp1918.long %>%
    left_join(site1918, by = "SiteID") %>%
    filter(Site == "China Poot") %>%
    group_by(Common) %>%
    summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
    select(Common,
           Total.CPUE = sum.sum.CPUE) %>%
    ungroup() %>%
    select(Common,
           Chinapoot = Total.CPUE))
write.csv(chinapoot.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-chinapoot.csv", row.names = FALSE)

(glacier.cpue = spp1918.long %>%
    left_join(site1918, by = "SiteID") %>%
    filter(Site == "Glacier Spit") %>%
    group_by(Common) %>%
    summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
    select(Common,
           Total.CPUE = sum.sum.CPUE) %>%
    ungroup() %>%
    select(Common,
           Glacier = Total.CPUE))
write.csv(glacier.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-glacier.csv", row.names = FALSE)

(halibut.cpue = spp1918.long %>%
    left_join(site1918, by = "SiteID") %>%
    filter(Site == "Halibut Cove") %>%
    group_by(Common) %>%
    summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
    select(Common,
           Total.CPUE = sum.sum.CPUE) %>%
    ungroup() %>%
    select(Common,
           Halibut = Total.CPUE))
write.csv(halibut.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-halibut.csv", row.names = FALSE)

(tutka.cpue = spp1918.long %>%
    left_join(site1918, by = "SiteID") %>%
    filter(Site == "Tutka Bay") %>%
    group_by(Common) %>%
    summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
    select(Common,
           Total.CPUE = sum.sum.CPUE) %>%
    ungroup() %>%
    select(Common,
           Tutka = Total.CPUE))
write.csv(tutka.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-tutka.csv", row.names = FALSE)

(seldovia.cpue = spp1918.long %>%
    left_join(site1918, by = "SiteID") %>%
    filter(Site == "Seldovia Harbor") %>%
    group_by(Common) %>%
    summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = TRUE)) %>%
    select(Common,
           Total.CPUE = sum.sum.CPUE) %>%
    ungroup() %>%
    select(Common,
           Seldovia = Total.CPUE))
write.csv(seldovia.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-seldovia.csv", row.names = FALSE)

combined.cpue = anchor.cpue %>%
  full_join(barabara.cpue, by = "Common") %>%
  full_join(chinapoot.cpue, by = "Common") %>%
  full_join(glacier.cpue, by = "Common") %>%
  full_join(halibut.cpue, by = "Common") %>%
  full_join(tutka.cpue, by = "Common") %>%
  full_join(seldovia.cpue, by = "Common") %>%
  left_join(SpeciesList, by = "Common") %>%
  select(Family, Scientific, Common, Barabara, Glacier, Seldovia, Anchor, Chinapoot, Halibut, Tutka) %>%
  arrange(Family, Scientific) %>% 
  replace_na(list(Barabara = "--",
                  Glacier = "--",
                  Seldovia = "--",
                  Anchor = "--",
                  Chinapoot = "--",
                  Halibut = "--",
                  Tutka = "--"))
write.csv(combined.cpue, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/CPUE-combined.csv", row.names = FALSE)



########## Site sampling metrics ############

collection.stats = fish1918 %>%
  left_join(site1918) %>%
  group_by(Year, Site) %>%
  mutate(n_seines = n_distinct(SeineID),
         n_visits = n_distinct(SiteID),
         n_fish = sum(Count, na.rm = T)) %>%
  select(Year, FC, Location, Site, n_seines, n_visits, n_fish) %>%
  distinct() %>%
  arrange(Site)
write.csv(collection.stats, "/Users/chrisguo/Desktop/Directory/Nearshore-year2/Figures/Collection-stats.csv", row.names = FALSE)
 