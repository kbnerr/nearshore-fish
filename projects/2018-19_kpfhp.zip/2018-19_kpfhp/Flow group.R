# Influence of flow on fish community
library(tidyverse)
library(vegan)
library(goeveg)
library(ggpubr)
library(lubridate)

#source("/Users/chrisguo/Desktop/Directory/Nearshore-year2/R scripts/data prep KPFHP report.R")

######## Additional data prep ########
Reach18 = dat18 %>% select(SeineID, Reach)
reach = left_join(fish18, Reach18, by = "SeineID") %>%
  select(SeineID, SiteID, Reach) %>%
  distinct()

tmp = c("FHP1Anc", "FHP1Bar", "FHP1Tut", "FHP2Anc", "FHP4Anc") # these are site visits that were not part of the 'flow' sampling

spp.flow.full = fish18 %>% 
  filter(!SiteID %in% tmp) %>%
  select(SeineID, Common, Count) %>%
  group_by(SeineID, Common) %>%
  mutate(Seine.Count = sum(Count, na.rm = T)) %>%
  select(-Count) %>%
  distinct() %>% 
  left_join(., reach, by = "SeineID") %>%
  mutate(CPUE = (Seine.Count/Reach)^0.25) %>%
  select(SiteID, SeineID, Common, CPUE)

# Here is our spp CPUE data in long format:
spp.flow.long = spp.flow.full %>%
  group_by(SiteID, Common) %>%
  mutate(avg.CPUE = mean(CPUE, na.rm = T),
         sd.CPUE = sd(CPUE, na.rm = T),
         sum.CPUE = sum(CPUE, na.rm = T)) %>%
  select(SiteID, Common, avg.CPUE, sd.CPUE, sum.CPUE) %>%
  distinct()

# Let's take a look at the raw species CPUE:
spp.flow.long %>%
  ungroup() %>%
  select(Common, avg.CPUE) %>%
  group_by(Common) %>%
  summarise(sum.avg.CPUE = sum(avg.CPUE, na.rm = T)) %>%
  ggplot(data = ., aes(x = Common, y = sum.avg.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Species", y = "4th-Root CPUE")

# Seems okay, except that we may want to drop the unidentified species of which we could not define lifestage...
spp.flow.long = spp.flow.long %>%
  filter(!Common %in% c("Unidentified Sculpin", "Unidentified Gadid", "Unidentified Greenling", "Unidentified Flatfish"))
# One final check:
spp.flow.long %>%
  ungroup() %>%
  select(Common, avg.CPUE) %>%
  group_by(Common) %>%
  summarise(sum.avg.CPUE = sum(avg.CPUE)) %>%
  ggplot(data = ., aes(x = Common, y = sum.avg.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Species", y = "Summed Average 4th-Root CPUE")

spp.flow.long %>%
  ungroup() %>%
  select(Common, sum.CPUE) %>%
  group_by(Common) %>%
  summarise(sum.sum.CPUE = sum(sum.CPUE)) %>%
  ggplot(data = ., aes(x = Common, y = sum.sum.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Species", y = "Total 4th-Root CPUE")

# Great, now let's create our site x species data frame. We'll use the site average CPUE:
spp.flow = spp.flow.long %>%
  select(SiteID, Common, avg.CPUE) %>%
  spread(., Common, avg.CPUE)
spp.flow[is.na(spp.flow)] = 0

# Let's also take a look ahead at a site x family df using the site average CPUE
spp.flow.long %>%
  left_join(SpeciesList, by = "Common") %>%
  ungroup() %>%
  group_by(SiteID, Family) %>%
  transmute(sum.avg.CPUE = sum(avg.CPUE)) %>%
  distinct()

# view the data
spp.flow # Woo! lots of zero's

# We should check to see if any of these species do not occur at any sites now that two are removed...
colSums(spp.flow[-1])
# Let's view instances of single catch species...
colSums(spp.flow[-1] > 0)
# great!



# This is the full transformed family CPUE data
fam.flow.full = fish18 %>% 
  filter(!SiteID %in% tmp) %>%
  select(SeineID, Family, Count) %>%
  group_by(SeineID, Family) %>%
  mutate(Seine.Count = sum(Count, na.rm = T)) %>%
  select(-Count) %>%
  distinct() %>%
  left_join(., reach, by = "SeineID") %>%
  mutate(CPUE = (Seine.Count/Reach)^0.25) %>%
  select(SiteID, SeineID, Family, CPUE)

# Here is our family 2018 CPUE data in long format:
fam.flow.long = fam.flow.full %>%
  group_by(SiteID, Family) %>%
  mutate(avg.CPUE = mean(CPUE, na.rm = T),
         sd.CPUE = sd(CPUE, na.rm = T),
         sum.CPUE = sum(CPUE, na.rm = T)) %>%
  select(SiteID, Family, avg.CPUE, sd.CPUE, sum.CPUE) %>%
  distinct()

# Let's take a look at the raw family CPUE:
fam.flow.long %>%
  ungroup() %>%
  select(Family, avg.CPUE) %>%
  group_by(Family) %>%
  summarise(sum.avg.CPUE = sum(avg.CPUE, na.rm = T)) %>%
  ggplot(data = ., aes(x = Family, y = sum.avg.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Family", y = "Summed Average 4th-Root CPUE")

fam.flow.long %>%
  ungroup() %>%
  select(Family, sum.CPUE) %>%
  group_by(Family) %>%
  summarise(sum.sum.CPUE = sum(sum.CPUE, na.rm = T)) %>%
  ggplot(data = ., aes(x = Family, y = sum.sum.CPUE)) +
  geom_col() +
  theme(axis.text.x=element_text(angle=90, hjust = 1, vjust = 0.25)) +
  labs(x = "Family", y = "Total 4th-Root CPUE")

# Great, now let's create our site x family data frame. We'll use the site average CPUE:
fam.flow = fam.flow.long %>%
  select(SiteID, Family, avg.CPUE) %>%
  spread(., Family, avg.CPUE)
fam.flow[is.na(fam.flow)] = 0

# view the data
fam.flow # Woo! lots of zero's

# We should check to see if any of these families do not occur at any sites now that two are removed...
colSums(fam.flow[-1])
# Let's view instances of single catch families
colSums(fam.flow[-1] > 0)

# Let's double check that our long and spread data have the same species:
colnames(fam.flow[,-1])
sort(unique(fam.flow.long$Family))
colnames(fam.flow[,-1]) == sort(unique(fam.flow.long$Family))
# Looks good

# We need to create a site.flow df
site.flow = select(spp.flow, SiteID)
tmp2 = filter(site18, !SiteID %in% tmp)
site.flow = site.flow %>%
  left_join(tmp2, by = "SiteID")

site.flow$SiteID == fam.flow$SiteID # just checking this

rm(reach, Reach18, tmp, tmp2) # Don't need this anymore

######## NMDS Ordination of Family CPUE ########

# Let's make a data.matrix version of the fam.flow CPUE data:
fam.flow.matrix = data.matrix(fam.flow[!colnames(fam.flow) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
fam.flow.bc = vegdist(fam.flow.matrix, method = "bray")
round(fam.flow.bc, 2)

# Let's check our dimensions:
dimcheckMDS(fam.flow.matrix)
# looks like we're just below .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
fam.flow.mds2 = metaMDS(fam.flow.matrix, k = 2)
stressplot(fam.flow.mds2)
plot(fam.flow.mds2, type = "t")
scores(fam.flow.mds2)
fam.flow.mds2.scores = as.data.frame(scores(fam.flow.mds2))

# Add grouping variables for plotting:
fam.flow.mds2.scores$SiteID = site.flow$SiteID
fam.flow.mds2.scores$Site = site.flow$Site
fam.flow.mds2.scores$Date = site.flow$Date
fam.flow.mds2.scores$FC = site.flow$FC
fam.flow.mds2.spp = as.data.frame(scores(fam.flow.mds2, "species"))
fam.flow.mds2.spp$Species = rownames(fam.flow.mds2.spp)
fam.flow.mds2.scores = mutate(fam.flow.mds2.scores, Season = case_when(Date < "2018-09-01" ~ "Summer",
                                                             Date > "2018-09-01" ~ "Fall"))
fam.flow.mds2.scores$Season = factor(fam.flow.mds2.scores$Season, levels = c("Summer", "Fall"))

# NMDS colored by site
(p1 = ggplot(fam.flow.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_text(data = fam.flow.mds2.spp,
              aes(x = NMDS1, y = NMDS2, label = Species),
              size = 3.5, alpha = .9, check_overlap = FALSE) +
    geom_point(aes(colour = FC),
               size = 5) +
    geom_text(aes(label = NA),
              position = position_nudge(y = .05)) +
    theme_bw() + 
    theme(axis.text.x = element_blank(),  # remove x-axis text
          axis.text.y = element_blank(), # remove y-axis text
          axis.ticks = element_blank(),  # remove axis ticks
          axis.title.x = element_text(size = 15),
          axis.title.y = element_text(size = 15),
          panel.background = element_blank(), 
          panel.grid.major = element_blank(),  #remove major-grid labels
          panel.grid.minor = element_blank(),  #remove minor-grid labels
          plot.background = element_blank(),
          legend.position = c(.1, .05),
          legend.direction = "horizontal",
          legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
          text = element_text(family = "Times", size = 12)) +
    coord_cartesian())

annotate_figure(p1, top =  text_grob(paste("Stress =", round(fam.flow.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", fam.mds2$ndim, ", stress = ", round(fam.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(fam.mds2$stress, 3)),
# x = .9, family = "Times", size = 10))

######## NMDS Ordination of Species CPUE ########

# Let's make a data.matrix version of the spp.flow CPUE data:
spp.flow.matrix = data.matrix(spp.flow[!colnames(spp.flow) %in% c("SiteID")])

# Let's compute and examine CPUE Bray-Curtis dissimilarities among the sites:
spp.flow.bc = vegdist(spp.flow.matrix, method = "bray")
round(spp.flow.bc, 2)

# Let's check our dimensions:
dimcheckMDS(spp.flow.matrix)
# looks like we're just above .2 stress, so we'll go ahead and proceed in dimensions

### NMDS in 2 dimensions:
spp.flow.mds2 = metaMDS(spp.flow.matrix, k = 2)
stressplot(spp.flow.mds2)
plot(spp.flow.mds2, type = "t")
scores(spp.flow.mds2)
spp.flow.mds2.scores = as.data.frame(scores(spp.flow.mds2))

# Add grouping variables for plotting:
spp.flow.mds2.scores$SiteID = site.flow$SiteID
spp.flow.mds2.scores$Site = site.flow$Site
spp.flow.mds2.scores$Date = site.flow$Date
spp.flow.mds2.scores$Year = as.character(site.flow$Year)
spp.flow.mds2.spp = as.data.frame(scores(spp.flow.mds2, "species"))
spp.flow.mds2.spp$Species = rownames(spp.flow.mds2.spp)

spp.flow.mds2.scores = mutate(spp.flow.mds2.scores, Season = case_when(Date < "2018-09-01" ~ "Summer",
                                                                           Date > "2018-09-01" ~ "Fall"))
spp.flow.mds2.scores$Season = factor(spp.flow.mds2.scores$Season, levels = c("Summer", "Fall"))

# NMDS colored by Year
(p = ggplot(spp.flow.mds2.scores, aes(x = NMDS1, y = NMDS2)) +
    geom_text(data = spp.flow.mds2.spp,
              aes(x = NMDS1, y = NMDS2, label = Species),
              size = 3.5, alpha = .9, check_overlap = FALSE) +
    geom_point(aes(colour = Year),
               size = 5) +
    geom_text(aes(label = NA),
              position = position_nudge(y = .05)) +
    theme_bw() + 
    theme(axis.text.x = element_blank(),  # remove x-axis text
          axis.text.y = element_blank(), # remove y-axis text
          axis.ticks = element_blank(),  # remove axis ticks
          axis.title.x = element_text(size = 15),
          axis.title.y = element_text(size = 15),
          panel.background = element_blank(), 
          panel.grid.major = element_blank(),  #remove major-grid labels
          panel.grid.minor = element_blank(),  #remove minor-grid labels
          plot.background = element_blank(),
          legend.position = c(.90, .05),
          legend.direction = "horizontal",
          legend.background = element_rect(colour = "black", linetype = "solid", size = 0.25),
          text = element_text(family = "Times", size = 12)) +
    coord_cartesian())

annotate_figure(p, top =  text_grob(paste("Stress =", round(spp.flow.mds2$stress, 3)), x = 0.075, vjust = 4, family = "Times", size = 10))

#  labs(title = "Fig XX. nMDS ordination of species abundance",
#       subtitle = paste("dimensions = ", spp.mds2$ndim, ", stress = ", round(spp.mds2$stress, 3)))
# annotate_figure(p3, bottom = text_grob(paste("Stress =", round(spp.mds2$stress, 3)),

######## BETADISPER & ANOSIM ########
spp.flow.beta = betadisper(spp.flow.bc, site.flow$FC)
anova(spp.flow.beta)
permutest(spp.flow.beta, permutations = 4999)
TukeyHSD(spp.flow.beta)
plot(spp.flow.beta)

(spp.flow.ano = anosim(spp.flow.matrix, site.flow$FC, permutations = 4999))
summary(spp.flow.ano)
plot(spp.flow.ano)

######## IndicSpecies #########
library(indicspecies)

# multipatt by flow class
spp.flow.indval = multipatt(x = spp.flow.matrix, cluster = site.flow$FC,
                              func = "IndVal.g",
                              control = how(nperm = 4999))
summary(spp.flow.indval, indvalcomp = TRUE, alpha = 1)
spp.flow.indval$sign

summary(simper(spp.flow.matrix, site.flow$FC, permutations = 999))



######## Species CPUE x FC #########
spp.flow.long %>%
  left_join(site.flow) %>%
  ggplot(data = ., aes(x = Common, y = avg.CPUE, fill = as.character(FC))) +
  geom_errorbar(aes(ymin = avg.CPUE - sd.CPUE, ymax = avg.CPUE + sd.CPUE),
                position = "dodge") +
  geom_bar(stat = "identity", position = "dodge", width = 1)


spp.flow.long %>%
  filter(Common == "Lingcod")
