# Data query and EDA of NOAA's nearshore fish atlas

library(tidyverse)
library(ggmap)
register_google(key = "AIzaSyAgDUD1ib0F8phLDCyBqQvq9Bi_mU01LdE", write = TRUE)

(setwd(getwd()))

catch = read.csv("./data/Data_Catch.csv")
events = read.csv("./data/Data_Events.csv")
sites = read.csv("./data/Data_Sites.csv")
locale = read.csv("./data/Lookup_Locale.csv")
region = read.csv("./data/Lookup_Region.csv")
catch.plus = left_join(catch, events, by = "EventID") %>%
  left_join(., sites, by = "SiteID") %>%
  left_join(., locale, by = "LocaleID") %>%
  left_join(., region, by = "RegionID")

events.plus = events %>% 
  left_join(., sites, by = "SiteID") %>%
  left_join(., locale, by = "LocaleID") %>%
  left_join(., region, by = "RegionID")

map1 = get_map(location = geocode("Alaska"), source = "google", maptype = "satellite", crop = FALSE, zoom = 4)
ggmap(map1) +
  geom_point(data = events.plus, aes(x = Long1, y = Lat1), color = "red")

map2 = get_map(location = geocode("Seward, AK"), source = "google", maptype = "satellite", crop = FALSE, zoom = 7)
ggmap(map2) +
  geom_point(data = events.plus, aes(x = Long1, y = Lat1), color = "red")

str(events.plus)
events.plus$RegionCode %>% unique() # No Kodiak...

events.scak = events.plus %>%
  filter(RegionCode %in% c("PWS", "SCAK")) %>%
  filter(GearBasic == "beach seine") %>%
  filter(DataType == "fish")

str(events.scak)
events.scak$Date %>% range() # dates from 1999 to 2012... not accurate
events.scak$Temp # Temperature measurements
events.scak$Salinity # Salinity measurements
events.scak$Habitat %>% unique() # Habitat class (eelgrass, kelp. bedrock, sand-gravel)
events.scak$Location %>% unique() # unique locations
events.scak$SubLocale %>% unique()

catch.scak = left_join(events.scak, catch, by = "EventID")
catch.scak$EventID %>% unique() %>% length() # number of 'events'
catch.scak$SpCode %>% unique() # unique taxa
catch.scak$Unmeasured # 'Unmeasured' counts
sum(catch.scak$Unmeasured + 1) # Total individuals

#### OLD ####
scak = filter(dat, RegionID == 5) # filter for southcentral alaska

tmp = scak %>%
  dplyr::select(EventID,
                Date,
                GearSpecific,
                GearBasic,
                DayNight,
                Temp,
                Salinity,
                Locale = Locale.x,
                Location,
                SubLocale,
                Habitat) %>%
  distinct()

scak %>%
  filter(GearBasic == "beach seine") %>%
  select(EventID,
         SpCode) %>%
  distinct() %>%
  mutate(P = 1) %>%
  pivot_wider(names_from = SpCode,
              values_from = P,
              values_fill = 0)
