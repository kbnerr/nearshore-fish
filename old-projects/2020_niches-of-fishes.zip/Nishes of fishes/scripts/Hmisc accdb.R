#install.packages('Hmisc') #yes
#install.packages('checkmate')#no
library(Hmisc)
path = getwd()
file = 'FishAtlas-CoreData&2018NERRS.accdb'
(filepath = paste(path, '/', file, sep = ''))
mdb.get(filepath)
