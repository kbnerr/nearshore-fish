### RANDOM FOREST CODE- KATHARINE MILLER, ALASKA FISHERIES SCIENCE CENTER.####

library(randomForest)
library(verification)
library(pROC)

fulldata <- read.table("F:/TRAWL 11_11/AllEstFlat7_20.txt", sep="", header=TRUE)

rm(trainingP)
rm(training)

### LOAD DATA ###

datset<-read.table("F:/PA All Data/PhysMonthSMin5_122.txt", sep="", header=TRUE,colClasses="numeric")
fish<-read.table("F:/PA All Data/HellAll3_13.txt", sep="", header=TRUE, row.names=1)

phys<-datset[3:123]

species <- fish$PIPE

trainingP<-cbind(phys, species)
trainingP$species<-ifelse(trainingP$species>0,1,0)


#### RANDOM FOREST MODEL FOR PRESENCE/ABSENCE (modified from code by Falk Huettmann)#######


storage<-rep(NA,65)
#most of these variables are not needed, just for diagnostics included
d=0
e=0
f=0

#this one keeps the best performing tree judged by AUC
keepme=0

#this is for how many trees to run
TREES<-c(500,1000,1500)

#this holds a table where the results are stored
results<- data.frame (matrix (NA,60,3, dimnames = list(c(1:60),c("mtry", "ntree", "AUC"))))

#this one is the counter
c=1


for(i in 1:20){
  for(x in TREES){
    
    train.rfP<-randomForest(trainingP$species ~ ., data=trainingP,importance=TRUE,mtry=i,ntree=x)
    model<-predict(train.rfP, type="response", OOB=T)
    storage[c]<-roc(trainingP$species,model)$auc
    f<-storage[c]
    plot(model,trainingP$species, ylab="Observed", xlab ="Predicted",pch=19)
    "storage is"
    storage[c]
    f
    "d is"
    d
    
    if (f>keepme) {
      delme5P<-model
      test5mtrybestP.rf<-train.rfP
      e<-d
      "e selected in the loop is"
      e
      keepme<-f
      tryroc<-roc(trainingP$species, delme5P)
    }
    d<-storage[c] 
    results[c,1]<-train.rfP$mtry
    results[c,2]<-train.rfP$ntree
    results[c,3]<-f
    c<-c+1
  }
}

delme5Pb<-(round(delme5P[],3))
"best final model AUC is "
keepme

#### PLOT ROC ####
plot.roc(smooth(tryroc), print.thres=T, print.auc=T, col="blue", main="Seine ROC CP")

##plot(tryroc, print.auc=TRUE, main="ROC CP")
#rs <-smooth(tryroc, method="density")
#plot(rs, add=TRUE, col="red")

dev.copy(png,'ROC_CP_Trawl NM 2_21.png')
dev.off()

varImpPlot(test5mtrybestP.rf)
jpeg('CP PA Varibles NM 2_21.jpg')
varImpPlot(test5mtrybestP.rf, main="CP Variables NM 2_21 PA")
dev.off()

save(test5mtrybestP.rf, file="CPpa NM 2_21 Model")

partialPlot (test5mtrybestP.rf,trainingP, MONTH, plot=TRUE, main="")
fulldata <- read.table("F:/trawl 11_11/AllEstFlatStndMin4_18.txt", sep="", header=TRUE)
MONTH<-rep(4, 541)
fulldata<-cbind(fulldata, MONTH)

fdpredict<-predict(test5mtrybestP.rf, fulldata, norm.votes=TRUE, predict.all=FALSE,proximity=FALSE, nodes=FALSE)
fdpredict_predictions<-cbind(fulldata$UNIQUE, fulldata$Lon, fulldata$Lat, round(as.matrix(fdpredict[]),3))
write.csv(fdpredict_predictions, file ="Trawl_PA CP  NM 7_20.csv", row.names = TRUE)

##PA MODEL VARIABLE IMPORTANCE PLOTS##

imp <- importance(test5mtrybestP.rf)  # get the importance measures
impvar <- rownames(imp)[order(imp[, 1], decreasing=TRUE)]  # get the sorted names
pdf(file="CP Partial PA NM 2_21.pdf") 
op <- par(mfrow=c(2, 3))
for (i in 1:30) {
  partialPlot(test5mtrybestP.rf, trainingP, impvar[i], xlab=impvar[i],
              main=paste("Partial Dependence on", impvar[i]))
}
par(op)
dev.off()



###CLASSIFICATION ERROR##
presence<-ifelse(delme5P>=0.42,1,0)
tbl<-table(trainingP$species, presence)
zero<-sum(tbl[1,])
ones<-sum(tbl[2,])
tbl[1,]/zero
tbl[2,]/ones

sum(inddata$ispec==delme5P)/length(inddata$ispec)



####  PREDICTIONS FOR P/A MODEL USING FULL DATA - PREDICTS PROBABIITIES TO SPATIAL DATA#####
delme5Pb<-(round(delme5P[],3))
fullset_predictions<-cbind(trainingP$ID, trainingP$Lon,trainingP$Lat, trainingP$species,round(as.matrix(delme5P[]),3))
write.csv(fullset_predictions, file ="fullset_predictionsNSCP.csv", row.names = TRUE)
#fullset_predictions



##IDENTIFY LOWEST PROBABILITY ASSOCIATED WITH TRUE PRESENCE - unless below 0.4, then identify second lowest###
min.prob=0
x.sub<-subset(fullset_predictions, fullset_predictions[,3]==1)
small <-min(x.sub[,4])
n <-length(x.sub[,4])
bob <- sort(x.sub[,4], partial=n-(n-2))[n-(n-2)]
if (small > .4) {min.prob<-small}
if (small < .4){min.prob<-bob}
min.prob
bob


### SELECT TRAINING SAMPLES FOR REGRESSION ANALYSIS ####
if (min.prob >= 0.4) {
  z <- which(fullset_predictions[,4] >=min.prob)
} 
if (min.prob < 0.4) {
  z <- which(fullset_predictions[,4] > 0.403)
}



###CLEAR VARIABLES###

rm (delme5)
rm (test5mtrybest.rf)
rm (d)
rm (e)
rm (f)
rm(keepme)
rm(results)
rm(test5mtrybest_predictions)
rm(fullset_predictions)
rm(z)
remove(training)
remove(trainingP)




